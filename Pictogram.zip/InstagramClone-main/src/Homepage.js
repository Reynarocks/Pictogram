import React from 'react'
import './style/Homepage.css'
import Herosection from './Components/HeroSection'
function Homepage () {
        return (
            <div>
                <Herosection />
            </div>
        )
    
}

export default Homepage
